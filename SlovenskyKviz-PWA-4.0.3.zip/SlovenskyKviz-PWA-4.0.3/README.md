# Slovenský kvíz 4.0.3 – PWA

## Nasadenie

Obsah priečinka `pwa` nahrajte do koreňa webového priestoru alebo podadresára. PWA musí byť dostupná cez HTTPS; pri obyčajnom otvorení súboru `index.html` z disku sa service worker z bezpečnostných dôvodov neaktivuje.

Na lokálne overenie možno v rozbalenom priečinku spustiť napríklad:

```bash
python3 -m http.server 8080
```

Potom otvorte `http://localhost:8080`. Localhost je pre vývoj povolený aj bez HTTPS.

## Inštalácia

- Android/Chrome: menu prehliadača → **Nainštalovať aplikáciu** alebo tlačidlo **Nainštalovať** v hlavičke.
- iPhone/Safari: **Zdieľať** → **Pridať na plochu**.
- Po prvom úplnom načítaní funguje vedomostná hra aj bez internetu.

## Obmedzenie multiplayera

Lokálna hra na jednom zariadení a hra proti mobilu fungujú. Priama Wi‑Fi miestnosť pre 2–4 telefóny používa v APK natívnu Android sieťovú vrstvu, preto v PWA nie je dostupná. Jej webové doplnenie vyžaduje HTTPS WebSocket server na synchronizáciu miestností.
